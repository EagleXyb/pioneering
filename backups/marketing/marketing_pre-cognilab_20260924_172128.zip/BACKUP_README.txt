﻿品牌站迁移前完整备份
====================
备份时间      : 20260924_172128
源目录        : d:\Administrator\Desktop\pioneering\apps\marketing
备份范围      : 全部源码 / 配置 / docs（含 docs/site 原型与设计文档）
排除项        : node_modules（依赖，可 npm install 重建）、.next（构建产物）
数据库        : 无（本应用无 DB / 无 API / 无业务数据，架构分析已确认）
媒体资源      : 无 public 目录、无位图/音视频（视觉资产均为内联 SVG）
文件总数      : 55
归档文件      : marketing_pre-cognilab_20260924_172128.zip
完整性校验    : 逐文件 SHA256 清单（BACKUP_MANIFEST.csv），解压后逐项比对
回退方法      : Expand-Archive 解压即可得到迁移前完整工作区
